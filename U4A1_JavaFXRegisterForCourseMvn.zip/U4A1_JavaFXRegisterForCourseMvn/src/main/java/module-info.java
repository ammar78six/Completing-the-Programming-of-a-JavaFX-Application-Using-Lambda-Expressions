module edu.capella.it3349.u4a1_javafxregisterforcourse {
    requires javafx.controls;
    exports edu.capella.it3349.u4a1_javafxregisterforcourse;
}
